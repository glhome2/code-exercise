# Install
install python3
install git
install modules requested
pip install wget
pip install gitpython
pip install urllib

# Path of manifest xml


# Run the script
